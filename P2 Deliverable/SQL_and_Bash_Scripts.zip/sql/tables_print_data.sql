
SELECT * FROM wall LIMIT 10;
SELECT * FROM creator LIMIT 10;
SELECT * FROM usert LIMIT 10;
SELECT * FROM page LIMIT 10;
SELECT * FROM submission LIMIT 10;
SELECT * FROM post LIMIT 10;
SELECT * FROM commentt LIMIT 10;
SELECT * FROM eventt LIMIT 10;
SELECT * FROM notification LIMIT 10;
SELECT * FROM page_follower LIMIT 10;
SELECT * FROM eventt_subscription LIMIT 10;
SELECT * FROM submission_like LIMIT 10;
SELECT * FROM feed_view LIMIT 10;
SELECT * FROM usert_friend LIMIT 10;
