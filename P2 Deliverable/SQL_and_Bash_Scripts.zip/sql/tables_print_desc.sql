
\d wall
\d creator
\d usert
\d page
\d submission
\d post
\d commentt
\d eventt
\d notification
\d page_follower
\d eventt_subscription
\d submission_like
\d feed_view
\d usert_friend
