
DROP TABLE usert_friend, feed_view, submission_like, eventt_subscription, page_follower, notification, eventt, commentt, post, submission, page, usert, creator, wall CASCADE;
